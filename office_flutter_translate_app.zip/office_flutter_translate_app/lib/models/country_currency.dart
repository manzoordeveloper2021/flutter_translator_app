class CountryCurrency {
  final String currencyName;
  final String currencyCode;
  final String currencySymbol;

  CountryCurrency({this.currencyName, this.currencyCode, this.currencySymbol});
}