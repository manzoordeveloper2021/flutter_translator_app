class Language {
  String name;
  String code;


  Language(String code, String name) {
    this.name = name;
    this.code = code;
  }
}
