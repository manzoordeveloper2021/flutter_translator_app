import 'package:flutter/cupertino.dart';
import 'package:office_flutter_translate_app/constants/lists.dart';
import 'package:office_flutter_translate_app/models/country_currency.dart';

class CountryCurrencyProvider extends ChangeNotifier {
//   int _index = 0;
//
// // ignore: unnecessary_getters_setters
//   int get index => _index;
//
//   // ignore: unnecessary_getters_setters
//   set index(int value) {
//     _index = value;
//   }

  // CountryCurrency firstCountryCurrency = CountryCurrency(currencyNameList[1],
  //     currencyCodeList[1], currencySymbolList[1]);
  //
  // setFirstCountyCurrencyDetails(int index) {
  //   firstCountryCurrency = CountryCurrency(currencyNameList[index],
  //       currencyCodeList[index], currencySymbolList[index]);
  //   print('First Country: ${firstCountryCurrency.currencyName}');
  //   notifyListeners();
  // }
  //
  // CountryCurrency secondCountryCurrency = CountryCurrency(currencyNameList[5],
  //     currencyCodeList[5], currencySymbolList[5]);
  //
  // setSecondCountyCurrencyDetails(int index) {
  //   secondCountryCurrency = CountryCurrency(currencyNameList[index],
  //       currencyCodeList[index], currencySymbolList[index]);
  //   notifyListeners();
  // }
}
