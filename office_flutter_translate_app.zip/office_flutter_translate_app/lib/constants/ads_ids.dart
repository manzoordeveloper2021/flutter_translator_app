class AdsIds {

  //original ad ids

  // static const bannerAdsId = 'ca-app-pub-2636058096681713/7306361298';
  // static const nativeAdsId = 'ca-app-pub-2636058096681713/3551304333';
  // static const interstitialAdsId = 'ca-app-pub-2636058096681713/7083355239';



  //test ad ids

  // static const bannerAdsId = 'ca-app-pub-3940256099942544/6300978111';
  // static const nativeAdsId = 'ca-app-pub-3940256099942544/8135179316';
  // static const interstitialAdsId = 'ca-app-pub-3940256099942544/1033173712';



  //Mediation ad ids

  static const bannerAdsId = 'ca-app-pub-9690383257630965/6168590745';
  static const nativeBannerAdsId = 'ca-app-pub-9690383257630965/5967132966';
  static const nativeAdsId = 'ca-app-pub-9690383257630965/8842855544';
  static const interstitialAdsId = 'ca-app-pub-9690383257630965/4855509074';

}

