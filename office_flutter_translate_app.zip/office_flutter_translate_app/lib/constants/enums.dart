enum TtsState { playing, stopped, paused, continued }
