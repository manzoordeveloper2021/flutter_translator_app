import 'package:flutter/material.dart';

class MediumNativeBannerContainer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 150,
      color: Colors.white,
      child: Center(child: Text('Banner Ads Area')),
    );
  }
}
